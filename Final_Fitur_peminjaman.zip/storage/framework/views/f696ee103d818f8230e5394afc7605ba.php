<?php $__env->startSection('title', 'Jadwal Ruangan'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active" aria-current="page">
    <i class="fas fa-calendar-alt"></i> Jadwal Ruangan
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
<div class="card jadwal-card">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('jadwal.index')); ?>">
            <div class="row g-3 align-items-end">
                <div class="col-12 col-md-3">
                    <label for="search" class="form-label fw-bold">Cari Ruangan:</label>
                    <input type="text" 
                           name="search" 
                           id="search" 
                           class="form-control" 
                           placeholder="Nama ruang, kelas..."
                           value="<?php echo e($searchQuery ?? ''); ?>">
                </div>
                <div class="col-12 col-md-3">
                    <label for="tanggal" class="form-label fw-bold">Tanggal:</label>
                    <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo e($selectedTanggal); ?>">
                </div>
                <div class="col-12 col-md-3">
                    <label for="status" class="form-label fw-bold">Status Ruangan:</label>
                    <select name="status" id="status" class="form-select">
                        <option value="all" <?php echo e($statusFilter == 'all' ? 'selected' : ''); ?>>Semua Status</option>
                        <option value="kosong" <?php echo e($statusFilter == 'kosong' ? 'selected' : ''); ?>>Kosong</option>
                        <option value="dipakai" <?php echo e($statusFilter == 'dipakai' ? 'selected' : ''); ?>>Dipakai</option>
                        <option value="relocated" <?php echo e($statusFilter == 'relocated' ? 'selected' : ''); ?>>Pengguna Default Dipindahkan</option>
                    </select>
                </div>
                <div class="col-12 col-md-3">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search me-1"></i>Tampilkan</button>
                    <?php if($searchQuery || $statusFilter != 'all'): ?>
                        <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-secondary w-100 mt-2">
                            <i class="fas fa-times me-1"></i>Reset Filter
                        </a>
                    <?php endif; ?>
                    <small class="text-muted text-navy">Cari berdasarkan nama atau pengguna</small>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-triangle me-2"></i><?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<!-- Info Hasil Pencarian/Filter -->
<?php if($searchQuery || $statusFilter != 'all'): ?>
<div class="alert alert-light border">
    <div class="row align-items-center">
        <div class="col-12 col-md-8">
            <i class="fas fa-filter me-2"></i>
            <strong>Filter Aktif:</strong>
            <?php if($searchQuery): ?>
                Pencarian: "<strong><?php echo e($searchQuery); ?></strong>"
            <?php endif; ?>
            <?php if($statusFilter != 'all'): ?>
                <?php if($searchQuery): ?> | <?php endif; ?>
                Status: <strong>
                    <?php if($statusFilter == 'kosong'): ?> Kosong
                    <?php elseif($statusFilter == 'dipakai'): ?> Dipakai
                    <?php elseif($statusFilter == 'relocated'): ?> Pengguna Default Dipindahkan
                    <?php endif; ?>
                </strong>
            <?php endif; ?>
        </div>
        <div class="col-12 col-md-4 text-md-end mt-2 mt-md-0">
            <span class="badge bg-primary me-2">
                <i class="fas fa-door-open"></i> <?php echo e($ruangs->count()); ?> Ruangan Ditemukan
            </span>
            <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-sm btn-outline-secondary">
                <i class="fas fa-times"></i> Reset
            </a>
        </div>
    </div>
</div>
<?php endif; ?>

    <!-- Jadwal Ruangan Accordion -->
    <div class="accordion" id="jadwalRuangan">
        <?php if($ruangs->count() > 0): ?>
            <?php $__currentLoopData = $ruangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $hasActiveBooking = $ruang->peminjaman && $ruang->peminjaman->count() > 0;
            $isRelocated = $ruang->is_temporary_occupied ?? false;
            // Prioritas status
            if ($isRelocated) {
                $statusColor = 'warning';
                $statusText = 'Dipindahkan Sementara';
                $statusIcon = 'exchange-alt';
            } elseif ($hasActiveBooking || $ruang->status === 'dipakai') {
                $statusColor = 'danger';
                $statusText = 'Dipakai';
                $statusIcon = 'times-circle';
            } else {
                $statusColor = 'success';
                $statusText = 'Kosong';
                $statusIcon = 'check-circle';
            }
        ?>
        <div class="accordion-item mb-3">
            <h2 class="accordion-header" id="heading<?php echo e($ruang->id_ruang); ?>">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($ruang->id_ruang); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($ruang->id_ruang); ?>">
                    <i class="fas fa-<?php echo e($statusIcon); ?> me-2 text-<?php echo e($statusColor); ?>"></i>
                    <strong><?php echo e($ruang->nama_ruang); ?></strong>
                    <span class="badge bg-<?php echo e($statusColor); ?> ms-2">
                        <i class="fas fa-<?php echo e($statusIcon); ?>"></i> <?php echo e($statusText); ?>

                    </span>
                    <?php if($isRelocated && $ruang->pengguna_default_temp): ?>
                        <span class="badge bg-info ms-2" title="Pengguna Default Dipindahkan Sementara">
                            <i class="fas fa-user-clock"></i> <?php echo e($ruang->pengguna_default_temp); ?>

                        </span>
                    <?php elseif($ruang->pengguna_default): ?>
                        <small class="text-muted ms-2">
                            <i class="fas fa-user"></i> <?php echo e($ruang->pengguna_default); ?>

                        </small>
                    <?php endif; ?>
                    <?php if(Auth::user()->role === 'admin'): ?>
                        <button type="button" class="btn btn-sm btn-outline-primary ms-auto me-2" data-bs-toggle="modal" data-bs-target="#editPenggunaModal<?php echo e($ruang->id_ruang); ?>">
                            <i class="fas fa-edit"></i> Edit Pengguna
                        </button>
                    <?php endif; ?>
                </button>
            </h2>
            <div id="collapse<?php echo e($ruang->id_ruang); ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo e($ruang->id_ruang); ?>" data-bs-parent="#jadwalRuangan">
                <div class="accordion-body">
                    <p class="text-muted mb-3">
                        <i class="fas fa-users"></i> Kapasitas: <?php echo e($ruang->kapasitas); ?> orang
                    </p>

                    
                    <?php if($ruang->pengguna_default && !$ruang->is_temporary_occupied): ?>
                        <div class="alert alert-info mb-3">
                            <h6 class="alert-heading mb-2">
                                <i class="fas fa-user-tag"></i> Pengguna Default Ruangan
                            </h6>
                            <p class="mb-1"><strong><?php echo e($ruang->pengguna_default); ?></strong></p>
                            <?php if($ruang->keterangan_penggunaan): ?>
                                <small class="text-muted">
                                    <i class="fas fa-info-circle"></i> <?php echo e($ruang->keterangan_penggunaan); ?>

                                </small>
                            <?php else: ?>
                                <small class="text-muted">
                                    <i class="fas fa-info-circle"></i> Ruangan ini memiliki pengguna tetap untuk kegiatan reguler
                                </small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($ruang->is_temporary_occupied): ?>
                        <div class="alert alert-warning mb-3">
                            <h6 class="alert-heading mb-2">
                                <i class="fas fa-exchange-alt"></i> Menampung Pengguna Sementara
                            </h6>
                            <p class="mb-1"><strong><?php echo e($ruang->pengguna_default_temp); ?></strong></p>
                            <small class="text-muted">
                                <i class="fas fa-info-circle"></i> 
                                <?php if($ruang->ruangAsal): ?>
                                    Dipindahkan dari: <strong><?php echo e($ruang->ruangAsal->nama_ruang); ?></strong>
                                <?php endif; ?>
                                <?php echo e($ruang->keterangan_penggunaan ? ' - ' . $ruang->keterangan_penggunaan : ''); ?>

                            </small>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($ruang->peminjaman && $ruang->peminjaman->count() > 0): ?>
                        <h6 class="mb-2"><i class="fas fa-calendar-check"></i> Peminjaman Aktif:</h6>
                        <ul class="list-group mb-3">
                            <?php $__currentLoopData = $ruang->peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($p->user->nama ?? '—'); ?></h6>
                                        <p class="mb-1">
                                            <i class="fas fa-calendar"></i> 
                                            <?php echo e(\Carbon\Carbon::parse($p->tanggal_pinjam)->format('d/m/Y')); ?> - 
                                            <?php echo e(\Carbon\Carbon::parse($p->tanggal_kembali)->format('d/m/Y')); ?>

                                        </p>
                                        <p class="mb-1">
                                            <i class="fas fa-clock"></i> 
                                            <?php echo e($p->waktu_mulai); ?> - <?php echo e($p->waktu_selesai); ?>

                                        </p>
                                        <p class="mb-1">
                                            <i class="fas fa-clipboard"></i> 
                                            <strong>Keperluan:</strong> <?php echo e($p->keperluan); ?>

                                        </p>
                                        <?php if($p->catatan): ?>
                                            <small class="text-muted">
                                                <i class="fas fa-sticky-note"></i> <?php echo e($p->catatan); ?>

                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    <span class="badge bg-success">Approved</span>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <p class="text-muted mb-3">
                            <i class="fas fa-list"></i> Total peminjaman: <?php echo e($ruang->peminjaman->count()); ?>

                        </p>
                    <?php else: ?>
                        <?php if(!$ruang->pengguna_default && !$ruang->is_temporary_occupied): ?>
                            <div class="alert alert-success mb-3">
                                <i class="fas fa-check-circle"></i> Tidak ada peminjaman aktif. Ruangan tersedia untuk dipinjam.
                                <?php if(Auth::user()->role === 'peminjam'): ?>
                                    <br><small class="text-muted">Klik tombol "Ajukan Peminjaman" di bawah untuk mengajukan peminjaman ruangan ini.</small>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted mb-3">
                                <i class="fas fa-info-circle"></i> Tidak ada peminjaman dari pihak lain saat ini.
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>

                    
                    <?php if(Auth::user()->role === 'peminjam'): ?>
                        <div class="d-grid gap-2">
                            <a href="<?php echo e(route('peminjam.peminjaman.create', ['ruang_id' => $ruang->id_ruang])); ?>" class="btn btn-primary">
                                <i class="fas fa-plus-circle me-1"></i> Ajukan Peminjaman Ruangan Ini
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <!-- Tidak ada hasil -->
        <div class="alert alert-info text-center py-5">
            <i class="fas fa-search fa-3x mb-3"></i>
            <h5>Tidak ada ruangan ditemukan</h5>
            <p class="mb-0">
                <?php if($searchQuery): ?>
                    Tidak ada ruangan yang cocok dengan pencarian "<strong><?php echo e($searchQuery); ?></strong>"
                <?php elseif($statusFilter !== 'all'): ?>
                    Tidak ada ruangan dengan status "<strong><?php echo e(ucfirst($statusFilter)); ?></strong>" pada tanggal ini
                <?php else: ?>
                    Tidak ada data ruangan tersedia
                <?php endif; ?>
            </p>
            <?php if($searchQuery || $statusFilter != 'all'): ?>
                <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-primary mt-3">
                    <i class="fas fa-redo"></i> Reset Filter
                </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Modal Edit Pengguna Default -->
    <?php if(Auth::user()->role === 'admin'): ?>
        <?php $__currentLoopData = $ruangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editPenggunaModal<?php echo e($ruang->id_ruang); ?>" tabindex="-1" aria-labelledby="editPenggunaModalLabel<?php echo e($ruang->id_ruang); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editPenggunaModalLabel<?php echo e($ruang->id_ruang); ?>">Edit Pengguna Default - <?php echo e($ruang->nama_ruang); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('admin.ruang.update', $ruang->id_ruang)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="status<?php echo e($ruang->id_ruang); ?>" class="form-label">Status Ruangan</label>
                                <select class="form-select" id="status<?php echo e($ruang->id_ruang); ?>" name="status" required>
                                    <option value="kosong" <?php echo e($ruang->status == 'kosong' ? 'selected' : ''); ?>>Kosong</option>
                                    <option value="dipakai" <?php echo e($ruang->status == 'dipakai' ? 'selected' : ''); ?>>Dipakai</option>
                                </select>
                            </div>
                            <div class="mb-3 pengguna-default-fields" id="penggunaDefaultFields<?php echo e($ruang->id_ruang); ?>" style="display: <?php echo e($ruang->status == 'dipakai' ? 'block' : 'none'); ?>;">
                                <label for="pengguna_default<?php echo e($ruang->id_ruang); ?>" class="form-label">Pengguna Default <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="pengguna_default<?php echo e($ruang->id_ruang); ?>" name="pengguna_default" value="<?php echo e($ruang->pengguna_default); ?>" placeholder="Contoh: Kelas 10A, Guru Matematika, dll" <?php echo e($ruang->status == 'dipakai' ? 'required' : ''); ?>>
                                <div class="form-text">Siapa yang secara default menggunakan ruangan ini?</div>
                            </div>
                            <div class="mb-3 pengguna-default-fields" id="keteranganPenggunaanFields<?php echo e($ruang->id_ruang); ?>" style="display: <?php echo e($ruang->status == 'dipakai' ? 'block' : 'none'); ?>;">
                                <label for="keterangan_penggunaan<?php echo e($ruang->id_ruang); ?>" class="form-label">Keterangan Penggunaan</label>
                                <textarea class="form-control" id="keterangan_penggunaan<?php echo e($ruang->id_ruang); ?>" name="keterangan_penggunaan" rows="3" placeholder="Jelaskan penggunaan ruangan ini secara default"><?php echo e($ruang->keterangan_penggunaan); ?></textarea>
                                <div class="form-text">Opsional: Jelaskan kegiatan yang biasanya dilakukan di ruangan ini</div>
                            </div>
                            <div class="mb-3">
                                <div class="form-text">
                                    <strong>Catatan:</strong> Perubahan ini akan mempengaruhi status dan pengguna default ruangan.
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>

<script>
<?php if(Auth::user()->role === 'admin'): ?>
document.addEventListener('DOMContentLoaded', function() {
    // Handle dynamic fields for each modal
    <?php $__currentLoopData = $ruangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    (function() {
        const modalId = '<?php echo e($ruang->id_ruang); ?>';
        const statusSelect = document.getElementById('status' + modalId);
        const penggunaDefaultFields = document.getElementById('penggunaDefaultFields' + modalId);
        const keteranganPenggunaanFields = document.getElementById('keteranganPenggunaanFields' + modalId);
        const penggunaDefaultInput = document.getElementById('pengguna_default' + modalId);

        function togglePenggunaFields() {
            if (statusSelect.value === 'dipakai') {
                penggunaDefaultFields.style.display = 'block';
                keteranganPenggunaanFields.style.display = 'block';
                penggunaDefaultInput.required = true;
            } else {
                penggunaDefaultFields.style.display = 'none';
                keteranganPenggunaanFields.style.display = 'none';
                penggunaDefaultInput.required = false;
                penggunaDefaultInput.value = '';
                document.getElementById('keterangan_penggunaan' + modalId).value = '';
            }
        }

        if (statusSelect) {
            statusSelect.addEventListener('change', togglePenggunaFields);
            // Set initial state
            togglePenggunaFields();
        }
    })();
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
});
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/jadwal/index.blade.php ENDPATH**/ ?>