<?php $__env->startSection('title', 'Detail Peminjaman'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item">
    <a href="<?php echo e(route('peminjam.peminjaman.index')); ?>">Peminjaman Saya</a>
</li>
<li class="breadcrumb-item active">Detail Peminjaman</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title"><i class="fas fa-info-circle"></i> Detail Peminjaman</h5>
                    <div>
                        <a href="<?php echo e(route('peminjam.peminjaman.index')); ?>" class="btn btn-secondary btn-sm">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php
                        $statusColors = [
                            'pending' => 'warning',
                            'approved' => 'success',
                            'rejected' => 'danger',
                            'cancelled' => 'secondary',
                            'selesai' => 'info'
                        ];
                    ?>

                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">Ruangan</th>
                                    <td><?php echo e($peminjaman->ruang->nama_ruang); ?></td>
                                </tr>
                                <tr>
                                    <th>Kapasitas</th>
                                    <td><?php echo e($peminjaman->ruang->kapasitas); ?> orang</td>
                                </tr>
                                <tr>
                                    <th>Tanggal Mulai</th>
                                    <td><?php echo e(\Carbon\Carbon::parse($peminjaman->tanggal_pinjam)->format('d/m/Y')); ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal Selesai</th>
                                    <td><?php echo e(\Carbon\Carbon::parse($peminjaman->tanggal_kembali)->format('d/m/Y')); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">Waktu</th>
                                    <td><?php echo e($peminjaman->waktu_mulai); ?> - <?php echo e($peminjaman->waktu_selesai); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <span class="badge bg-<?php echo e($statusColors[$peminjaman->status] ?? 'secondary'); ?>">
                                            <?php echo e(ucfirst($peminjaman->status)); ?>

                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Diajukan Pada</th>
                                    <td><?php echo e($peminjaman->created_at->format('d/m/Y H:i')); ?></td>
                                </tr>
                                <tr>
                                    <th>Terakhir Update</th>
                                    <td><?php echo e($peminjaman->updated_at->format('d/m/Y H:i')); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold">Keperluan</label>
                        <div class="border p-3 rounded bg-light">
                            <?php echo e($peminjaman->keperluan); ?>

                        </div>
                    </div>

                    <?php if($peminjaman->catatan): ?>
                    <div class="mb-4">
                        <label class="form-label fw-bold">Catatan dari Admin/Petugas</label>
                        <div class="border p-3 rounded bg-light">
                            <?php echo e($peminjaman->catatan); ?>

                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($peminjaman->status == 'pending'): ?>
                    <div class="mt-4">
                        <form action="<?php echo e(route('peminjam.peminjaman.cancel', $peminjaman->id_peminjaman)); ?>" 
                              method="POST" 
                              onsubmit="return confirm('Apakah Anda yakin ingin membatalkan peminjaman ini?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-times"></i> Batalkan Peminjaman
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h6 class="mb-0"><i class="fas fa-building"></i> Informasi Ruangan</h6>
                </div>
                <div class="card-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-door-open fa-3x text-primary mb-2"></i>
                        <h5><?php echo e($peminjaman->ruang->nama_ruang); ?></h5>
                    </div>
                    
                    <table class="table table-sm">
                        <tr>
                            <td><strong>Kapasitas</strong></td>
                            <td><?php echo e($peminjaman->ruang->kapasitas); ?> orang</td>
                        </tr>
                        <tr>
                            <td><strong>Status Saat Ini</strong></td>
                            <td>
                                <span class="badge bg-<?php echo e($peminjaman->ruang->status == 'kosong' ? 'success' : 'danger'); ?>">
                                    <?php echo e($peminjaman->ruang->status); ?>

                                </span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-history"></i> Status Timeline</h6>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item <?php echo e($peminjaman->status == 'pending' ? 'active' : ''); ?>">
                            <div class="timeline-marker bg-warning"></div>
                            <div class="timeline-content">
                                <small>Diajukan</small>
                                <p class="mb-0"><?php echo e($peminjaman->created_at->format('d/m/Y H:i')); ?></p>
                            </div>
                        </div>
                        
                        <?php if(in_array($peminjaman->status, ['approved', 'rejected'])): ?>
                        <div class="timeline-item active">
                            <div class="timeline-marker bg-<?php echo e($peminjaman->status == 'approved' ? 'success' : 'danger'); ?>"></div>
                            <div class="timeline-content">
                                <small>Diproses</small>
                                <p class="mb-0"><?php echo e($peminjaman->updated_at->format('d/m/Y H:i')); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/peminjam/peminjaman/show.blade.php ENDPATH**/ ?>