<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Edit Ruang</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.ruang.update', $ruang->id_ruang)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="nama_ruang" class="form-label">Nama Ruang</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_ruang" name="nama_ruang" value="<?php echo e(old('nama_ruang', $ruang->nama_ruang)); ?>" required>
                            <?php $__errorArgs = ['nama_ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="kapasitas" class="form-label">Kapasitas</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['kapasitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kapasitas" name="kapasitas" value="<?php echo e(old('kapasitas', $ruang->kapasitas)); ?>" min="1" required>
                            <?php $__errorArgs = ['kapasitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" required>
                                <option value="">Pilih Status</option>
                                <option value="kosong" <?php echo e(old('status', $ruang->status) == 'kosong' ? 'selected' : ''); ?>>Kosong</option>
                                <option value="dipakai" <?php echo e(old('status', $ruang->status) == 'dipakai' ? 'selected' : ''); ?>>Dipakai</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 pengguna-default-fields" id="penggunaDefaultFields" style="display: none;">
                            <label for="pengguna_default" class="form-label">Pengguna Default <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['pengguna_default'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pengguna_default" name="pengguna_default" value="<?php echo e(old('pengguna_default', $ruang->pengguna_default)); ?>" placeholder="Contoh: Kelas 10A, Guru Matematika, dll">
                            <div class="form-text">Siapa yang secara default menggunakan ruangan ini?</div>
                            <?php $__errorArgs = ['pengguna_default'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 pengguna-default-fields" id="keteranganPenggunaanFields" style="display: none;">
                            <label for="keterangan_penggunaan" class="form-label">Keterangan Penggunaan</label>
                            <textarea class="form-control <?php $__errorArgs = ['keterangan_penggunaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="keterangan_penggunaan" name="keterangan_penggunaan" rows="3" placeholder="Jelaskan penggunaan ruangan ini secara default"><?php echo e(old('keterangan_penggunaan', $ruang->keterangan_penggunaan)); ?></textarea>
                            <div class="form-text">Opsional: Jelaskan kegiatan yang biasanya dilakukan di ruangan ini</div>
                            <?php $__errorArgs = ['keterangan_penggunaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(route('admin.ruang.index')); ?>" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const statusSelect = document.getElementById('status');
    const penggunaDefaultFields = document.getElementById('penggunaDefaultFields');
    const keteranganPenggunaanFields = document.getElementById('keteranganPenggunaanFields');
    const penggunaDefaultInput = document.getElementById('pengguna_default');

    function togglePenggunaDefaultFields() {
        if (statusSelect.value === 'dipakai') {
            penggunaDefaultFields.style.display = 'block';
            keteranganPenggunaanFields.style.display = 'block';
            penggunaDefaultInput.setAttribute('required', 'required');
        } else {
            penggunaDefaultFields.style.display = 'none';
            keteranganPenggunaanFields.style.display = 'none';
            penggunaDefaultInput.removeAttribute('required');
        }
    }

    // Initial check on page load
    togglePenggunaDefaultFields();

    // Listen for changes
    statusSelect.addEventListener('change', togglePenggunaDefaultFields);
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/admin/ruang/edit.blade.php ENDPATH**/ ?>