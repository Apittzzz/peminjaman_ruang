        <?php $__env->startSection('title', 'Persetujuan Peminjaman'); ?>

        <?php $__env->startSection('breadcrumb'); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <i class="fas fa-check-circle"></i> Persetujuan Peminjaman
        </li>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <div class="row mb-3">
                <div class="col-md-12">
                    <div class="d-flex justify-content-between align-items-center text">
                        <h4><i class="fas fa-check-circle"></i> Persetujuan Peminjaman</h4>
                        <div>
                            <a href="<?php echo e(Auth::user()->role === 'admin' ? route('admin.dashboard') : route('petugas.dashboard')); ?>" 
                            class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Kembali
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Simple Table -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-warning text-dark">
                            <h5 class="mb-0"><i class="fas fa-clock"></i> Menunggu Persetujuan (<?php echo e($peminjaman->count()); ?>)</h5>
                        </div>
                        <div class="card-body">
                            <?php if($peminjaman->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>#</th>
                                            <th>Peminjam</th>
                                            <th>Ruangan</th>
                                            <th>Tanggal</th>
                                            <th>Waktu</th>
                                            <th>Keperluan</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->user->nama); ?></td>
                                            <td><?php echo e($item->ruang->nama_ruang); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_pinjam)->format('d/m/Y')); ?></td>
                                            <td><?php echo e($item->waktu_mulai); ?> - <?php echo e($item->waktu_selesai); ?></td>
                                            <td><?php echo e(Str::limit($item->keperluan, 50)); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('persetujuan.approve', $item->id_peminjaman)); ?>" 
                                                    method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-success btn-sm" 
                                                            onclick="return confirm('Setujui peminjaman ini?')">
                                                        <i class="fas fa-check"></i> Setujui
                                                    </button>
                                                </form>

                                                <!-- allow petugas to manually mark as finished -->
                                                <?php if(Auth::user()->role === 'petugas'): ?>
                                                    <form action="<?php echo e(route('petugas.peminjaman.complete', $item->id_peminjaman)); ?>" method="POST" class="d-inline ms-1">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-info btn-sm" onclick="return confirm('Tandai peminjaman ini selesai?')">
                                                            <i class="fas fa-flag-checkered"></i> Selesai
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <button type="button" class="btn btn-danger btn-sm" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#rejectModal<?php echo e($item->id_peminjaman); ?>">
                                                    <i class="fas fa-times"></i> Tolak
                                                </button>

                                                <!-- Reject Modal -->
                                                <div class="modal fade" id="rejectModal<?php echo e($item->id_peminjaman); ?>" tabindex="-1">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header bg-danger text-white">
                                                                <h5 class="modal-title">Tolak Peminjaman</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                            </div>
                                                            <form action="<?php echo e(route('persetujuan.reject', $item->id_peminjaman)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-body">
                                                                    <div class="mb-3">
                                                                        <label class="form-label">Alasan Penolakan *</label>
                                                                        <textarea class="form-control" name="catatan" rows="3" required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-danger">Tolak</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                <h5 class="text-success">Tidak ada peminjaman yang menunggu persetujuan</h5>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/persetujuan/index.blade.php ENDPATH**/ ?>