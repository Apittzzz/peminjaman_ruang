<?php $__env->startSection('title', 'Manajemen Ruang'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active" aria-current="page">
    <i class="fas fa-door-open"></i> Manajemen Ruang
</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title">Manajemen Ruang</h5>
                    <a href="<?php echo e(route('admin.ruang.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Tambah Ruang
                    </a>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama Ruang</th>
                                    <th>Kapasitas</th>
                                    <th>Status</th>
                                    <th>Pengguna Default</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $ruangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($ruang->nama_ruang); ?></td>
                                    <td><?php echo e($ruang->kapasitas); ?> orang</td>
                                    <td>
                                        <span class="badge bg-<?php echo e($ruang->status == 'kosong' ? 'success' : 'danger'); ?>">
                                            <?php echo e($ruang->status); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if($ruang->pengguna_default): ?>
                                            <?php echo e($ruang->pengguna_default); ?>

                                            <?php if($ruang->keterangan_penggunaan): ?>
                                                <br><small class="text-muted"><?php echo e($ruang->keterangan_penggunaan); ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.ruang.show', $ruang->id_ruang)); ?>" class="btn btn-info btn-sm">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.ruang.edit', $ruang->id_ruang)); ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.ruang.destroy', $ruang->id_ruang)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus ruang ini?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Tidak ada data ruang.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/admin/ruang/index.blade.php ENDPATH**/ ?>