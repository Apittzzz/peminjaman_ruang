<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Sistem Peminjaman Ruang'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <i class="fas fa-building"></i> Sistem Peminjaman Ruang
            </a>
            
            <?php if(auth()->guard()->check()): ?>
            <div class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle"></i> <?php echo e(Auth::user()->nama); ?>

                    </a>
                    <ul class="dropdown-menu">
                        <li><span class="dropdown-item-text">
                            <small>Role: <?php echo e(ucfirst(Auth::user()->role)); ?></small>
                        </span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" id="logoutForm">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </li>
            </div>
            <?php else: ?>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="<?php echo e(route('login')); ?>">
                    <i class="fas fa-sign-in-alt"></i> Login
                </a>
                <a class="nav-link" href="<?php echo e(route('register')); ?>">
                    <i class="fas fa-user-plus"></i> Register
                </a>
            </div>
            <?php endif; ?>
        </div>
    </nav>

    <div class="container mt-3">
        <!-- Tampilkan status messages -->
        <?php if(session('status')): ?>
            <div class="alert alert-info alert-dismissible fade show">
                <i class="fas fa-info-circle"></i> <?php echo e(session('status')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i> <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="fas fa-home"></i> Dashboard Admin
                            </a>
                        <?php elseif(Auth::user()->role === 'petugas'): ?>
                            <a href="<?php echo e(route('petugas.dashboard')); ?>">
                                <i class="fas fa-home"></i> Dashboard Petugas
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('peminjam.dashboard')); ?>">
                                <i class="fas fa-home"></i> Dashboard Peminjam
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <!--<a href="<?php echo e(url('/')); ?>"><i class="fas fa-home"></i> Home</a> -->
                    <?php endif; ?>
                </li>
                <?php echo $__env->yieldContent('breadcrumb'); ?>
            </ol>
        </nav>

        <!-- Content -->
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle logout form submission
        document.addEventListener('DOMContentLoaded', function() {
            const logoutForm = document.getElementById('logoutForm');
            if (logoutForm) {
                logoutForm.addEventListener('submit', function(e) {
                    if (!confirm('Apakah Anda yakin ingin logout?')) {
                        e.preventDefault();
                    }
                });
            }

            // Auto-hide alerts after 5 seconds
            setTimeout(() => {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
        });
    </script>
</body>
</html><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/layouts/app.blade.php ENDPATH**/ ?>