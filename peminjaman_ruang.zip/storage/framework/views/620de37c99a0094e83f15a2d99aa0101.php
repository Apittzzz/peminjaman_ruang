<?php $__env->startSection('title', 'Laporan Peminjaman Ruangan'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active" aria-current="page">
    <i class="fas fa-file-alt"></i> Laporan Peminjaman
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Filter Periode -->
    <div class="card laporan-card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filter Laporan</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.laporan.index')); ?>" class="row g-3">
                <div class="col-12 col-md-4">
                    <label for="periode" class="form-label fw-bold">Pilih Periode:</label>
                    <select name="periode" id="periode" class="form-select" onchange="this.form.submit()">
                        <option value="hari_ini" <?php echo e($periode == 'hari_ini' ? 'selected' : ''); ?>>Hari Ini</option>
                        <option value="minggu_ini" <?php echo e($periode == 'minggu_ini' ? 'selected' : ''); ?>>Minggu Ini</option>
                        <option value="bulan_ini" <?php echo e($periode == 'bulan_ini' ? 'selected' : ''); ?>>Bulan Ini</option>
                        <option value="tahun_ini" <?php echo e($periode == 'tahun_ini' ? 'selected' : ''); ?>>Tahun Ini</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-bold">Periode Laporan:</label>
                    <div class="alert alert-info mb-0">
                        <i class="fas fa-calendar-alt me-2"></i>
                        <small><?php echo e(\Carbon\Carbon::parse($startDate)->format('d M Y')); ?> - <?php echo e(\Carbon\Carbon::parse($endDate)->format('d M Y')); ?></small>
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-bold">Export Laporan:</label>
                    <div class="d-flex flex-column flex-md-row gap-2">
                        <a href="<?php echo e(route('admin.laporan.export', ['periode' => $periode, 'format' => 'excel'])); ?>" class="btn btn-success">
                            <i class="fas fa-file-excel me-1"></i>Excel
                        </a>
                        <a href="<?php echo e(route('admin.laporan.export', ['periode' => $periode, 'format' => 'csv'])); ?>" class="btn btn-info">
                            <i class="fas fa-file-csv me-1"></i>CSV
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Statistik Cards - Responsive: 2 per row on mobile, 3 on tablet, 6 on desktop -->
    <div class="row">
        <div class="col-6 col-sm-4 col-md-2">
            <div class="card stat-card total">
                <div class="card-body text-center">
                    <i class="fas fa-clipboard-list stat-icon text-primary"></i>
                    <h3 class="mt-2 mb-0"><?php echo e($stats['total_peminjaman']); ?></h3>
                    <small class="text-muted text-light">Total Peminjaman</small>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-4 col-md-2">
            <div class="card stat-card pending">
                <div class="card-body text-center">
                    <i class="fas fa-clock stat-icon text-warning"></i>
                    <h3 class="mt-2 mb-0"><?php echo e($stats['pending']); ?></h3>
                    <small class="text-muted text-light">Pending</small>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-4 col-md-2">
            <div class="card stat-card approved">
                <div class="card-body text-center">
                    <i class="fas fa-check-circle stat-icon text-success"></i>
                    <h3 class="mt-2 mb-0"><?php echo e($stats['approved']); ?></h3>
                    <small class="text-muted text-light">Approved</small>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-4 col-md-2">
            <div class="card stat-card rejected">
                <div class="card-body text-center">
                    <i class="fas fa-times-circle stat-icon text-danger"></i>
                    <h3 class="mt-2 mb-0"><?php echo e($stats['rejected']); ?></h3>
                    <small class="text-muted text-light">Rejected</small>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-4 col-md-2">
            <div class="card stat-card selesai">
                <div class="card-body text-center">
                    <i class="fas fa-check-double stat-icon text-secondary"></i>
                    <h3 class="mt-2 mb-0"><?php echo e($stats['selesai']); ?></h3>
                    <small class="text-muted text-light">Selesai</small>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-4 col-md-2">
            <div class="card stat-card cancelled">
                <div class="card-body text-center">
                    <i class="fas fa-ban stat-icon text-secondary"></i>
                    <h3 class="mt-2 mb-0"><?php echo e($stats['cancelled']); ?></h3>
                    <small class="text-muted text-light">Cancelled</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Top 5 Ruangan & User -->
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-door-open me-2"></i>Top 5 Ruangan Terpopuler</h6>
                </div>
                <div class="card-body">
                    <?php if($ruangStats->count() > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php $__currentLoopData = $ruangStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="badge bg-primary me-2"><?php echo e($index + 1); ?></span>
                                    <strong><?php echo e($stat->ruang->nama_ruang ?? '-'); ?></strong>
                                </div>
                                <span class="badge bg-info rounded-pill"><?php echo e($stat->total); ?> peminjaman</span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center mb-0 text-light">Belum ada data</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="fas fa-users me-2"></i>Top 5 Peminjam Teraktif</h6>
                </div>
                <div class="card-body">
                    <?php if($userStats->count() > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php $__currentLoopData = $userStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="badge bg-primary me-2"><?php echo e($index + 1); ?></span>
                                    <strong><?php echo e($stat->user->nama ?? '-'); ?></strong>
                                </div>
                                <span class="badge bg-success rounded-pill"><?php echo e($stat->total); ?> peminjaman</span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center mb-0 text-light">Belum ada data</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabel Detail Peminjaman -->
    <div class="card">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0"><i class="fas fa-list me-2"></i>Detail Peminjaman</h5>
        </div>
        <div class="card-body">
            <?php if($peminjaman->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Tanggal Pengajuan</th>
                                <th>Peminjam</th>
                                <th>Ruangan</th>
                                <th>Tanggal Pinjam</th>
                                <th>Waktu</th>
                                <th>Keperluan</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($p->created_at->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($p->user->nama ?? '-'); ?></td>
                                <td><?php echo e($p->ruang->nama_ruang ?? '-'); ?></td>
                                <td>
                                    <?php echo e(\Carbon\Carbon::parse($p->tanggal_pinjam)->format('d/m/Y')); ?>

                                    <?php if($p->tanggal_pinjam != $p->tanggal_kembali): ?>
                                        - <?php echo e(\Carbon\Carbon::parse($p->tanggal_kembali)->format('d/m/Y')); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($p->waktu_mulai); ?> - <?php echo e($p->waktu_selesai); ?></td>
                                <td>
                                    <small><?php echo e(\Illuminate\Support\Str::limit($p->keperluan, 50)); ?></small>
                                </td>
                                <td>
                                    <?php if($p->status == 'pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($p->status == 'approved'): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php elseif($p->status == 'rejected'): ?>
                                        <span class="badge bg-danger">Rejected</span>
                                    <?php elseif($p->status == 'selesai'): ?>
                                        <span class="badge bg-secondary">Selesai</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e(ucfirst($p->status)); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info text-center">
                    <i class="fas fa-info-circle me-2"></i>Tidak ada data peminjaman pada periode ini.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/admin/laporan/index.blade.php ENDPATH**/ ?>