<?php $__env->startSection('title', 'Peminjaman Saya'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active" aria-current="page">
    <i class="fas fa-calendar-alt"></i> Peminjaman Saya
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row mb-3">
        <div class="col-12">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">
                <h4 class="text-dark mb-2 mb-md-0"><i class="fas fa-calendar-alt"></i> Peminjaman Saya</h4>
                <div class="d-flex flex-column flex-md-row gap-2 ms-md-auto">
                    <a href="<?php echo e(route('peminjam.dashboard')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
                    </a>
                    <a href="<?php echo e(route('peminjam.peminjaman.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Ajukan Peminjaman
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle"></i> <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if($peminjaman->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th class="d-none d-md-table-cell">#</th>
                                    <th>Ruangan</th>
                                    <th class="d-none d-md-table-cell">Tanggal Mulai</th>
                                    <th class="d-none d-md-table-cell">Tanggal Selesai</th>
                                    <th class="d-none d-lg-table-cell">Waktu</th>
                                    <th class="d-none d-lg-table-cell">Keperluan</th>
                                    <th>Status</th>
                                    <th class="d-none d-md-table-cell">Diajukan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="d-none d-md-table-cell"><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <strong><?php echo e($item->ruang->nama_ruang); ?></strong>
                                        <br>
                                        <small class="text-muted">Kapasitas: <?php echo e($item->ruang->kapasitas); ?> orang</small>
                                        
                                        <div class="d-md-none mt-2">
                                            <small class="d-block">
                                                <i class="fas fa-calendar"></i> 
                                                <?php echo e(\Carbon\Carbon::parse($item->tanggal_pinjam)->format('d/m/Y')); ?> - 
                                                <?php echo e(\Carbon\Carbon::parse($item->tanggal_kembali)->format('d/m/Y')); ?>

                                            </small>
                                            <small class="d-block">
                                                <i class="fas fa-clock"></i> 
                                                <?php echo e($item->waktu_mulai); ?> - <?php echo e($item->waktu_selesai); ?>

                                            </small>
                                        </div>
                                    </td>
                                    <td class="d-none d-md-table-cell"><?php echo e(\Carbon\Carbon::parse($item->tanggal_pinjam)->format('d/m/Y')); ?></td>
                                    <td class="d-none d-md-table-cell"><?php echo e(\Carbon\Carbon::parse($item->tanggal_kembali)->format('d/m/Y')); ?></td>
                                    <td class="d-none d-lg-table-cell">
                                        <span class="badge bg-primary"><?php echo e($item->waktu_mulai); ?></span>
                                        <br>
                                        <span class="badge bg-secondary"><?php echo e($item->waktu_selesai); ?></span>
                                    </td>
                                    <td class="d-none d-lg-table-cell"><?php echo e(Str::limit($item->keperluan, 50)); ?></td>
                                    <td>
                                        <?php
                                            $statusColors = [
                                                'pending' => 'warning',
                                                'approved' => 'success',
                                                'rejected' => 'danger',
                                                'cancelled' => 'secondary'
                                            ];
                                            $statusText = [
                                                'pending' => 'Menunggu',
                                                'approved' => 'Disetujui',
                                                'rejected' => 'Ditolak',
                                                'cancelled' => 'Dibatalkan'
                                            ];
                                        ?>
                                        <span class="badge bg-<?php echo e($statusColors[$item->status] ?? 'secondary'); ?>">
                                            <?php echo e($statusText[$item->status] ?? ucfirst($item->status)); ?>

                                        </span>

                                    </td>
                                    <td class="d-none d-md-table-cell"><?php echo e($item->created_at->format('d/m/Y H:i')); ?></td>
                                    <td>
                                        <div class="d-flex flex-column flex-md-row gap-1">
                                            <a href="<?php echo e(route('peminjam.peminjaman.show', $item->id_peminjaman)); ?>" 
                                               class="btn btn-info btn-sm" title="Lihat Detail">
                                                <i class="fas fa-eye"></i><span class="d-md-none ms-1">Detail</span>
                                            </a>
                                            <?php if($item->status == 'pending'): ?>
                                            <form action="<?php echo e(route('peminjam.peminjaman.cancel', $item->id_peminjaman)); ?>" 
                                                  method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-warning btn-sm w-100" 
                                                        onclick="return confirm('Batalkan peminjaman ini?')"
                                                        title="Batalkan Peminjaman">
                                                    <i class="fas fa-times"></i><span class="d-md-none ms-1">Batalkan</span>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">Belum ada peminjaman</h5>
                        <p class="text-muted">Mulai dengan mengajukan peminjaman ruangan pertama Anda</p>
                        <a href="<?php echo e(route('peminjam.peminjaman.create')); ?>" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Ajukan Peminjaman Pertama
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik Peminjaman -->
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white stats-card">
                <div class="card-body text-center">
                    <h5 class="card-title">Total</h5>
                    <h3><?php echo e($peminjaman->count()); ?></h3>
                    <p class="card-text">Semua Peminjaman</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white stats-card">
                <div class="card-body text-center">
                    <h5 class="card-title">Menunggu</h5>
                    <h3><?php echo e($peminjaman->where('status', 'pending')->count()); ?></h3>
                    <p class="card-text">Menunggu Persetujuan</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white stats-card">
                <div class="card-body text-center">
                    <h5 class="card-title">Disetujui</h5>
                    <h3><?php echo e($peminjaman->where('status', 'approved')->count()); ?></h3>
                    <p class="card-text">Peminjaman Aktif</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-secondary text-white stats-card">
                <div class="card-body text-center">
                    <h5 class="card-title">Selesai</h5>
                    <h3><?php echo e($peminjaman->whereIn('status', ['rejected', 'cancelled'])->count()); ?></h3>
                    <p class="card-text">Peminjaman Selesai</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/apitaja/peminjaman_ruang/resources/views/peminjam/peminjaman/index.blade.php ENDPATH**/ ?>